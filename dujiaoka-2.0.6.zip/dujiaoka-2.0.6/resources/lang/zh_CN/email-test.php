<?php
/**
 * The file was created by Assimon.
 *
 * @author    ZhangYiQiu<me@zhangyiqiu.net>
 * @copyright ZhangYiQiu<me@zhangyiqiu.net>
 * @link      http://zhangyiqiu.net/
 */

return [
    'labels' => [
        'success' => '发送成功',
        'to' => '收件人',
        'title' => '邮件标题',
        'body' => '邮件内容',
    ],

    'fields' => [
        
    ],
    'options' => [
    ],
    'rule_messages' => [
    ]
];
