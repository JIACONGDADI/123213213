<div class="main layui-hide-xs">
  <div class="layui-row">
    <div class="layui-col-sm12">
        <div class="main-box">
        <div class="title">
              <p class="tit">{{ __('dujiaoka.site_announcement') }}:</p>
          </div>
          <div class="goods">
              <div class="tips">{!! dujiaoka_config_get('notice') !!}</div>
          </div>
      </div>
    </div>
  </div>
</div>